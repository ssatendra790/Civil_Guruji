import { defineStyleConfig } from "@chakra-ui/react";

export const buttonTheme = defineStyleConfig({
  defaultProps: {
    colorScheme: "purple",
  },
});
