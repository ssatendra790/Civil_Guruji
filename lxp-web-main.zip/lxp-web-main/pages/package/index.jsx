import Layout from "@/components/reusable/Layout";
import React from "react";

export default function Package() {
  return <Layout>Welcome to package</Layout>;
}
